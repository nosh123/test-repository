#!/bin/bash 

KBS_RUNNING_VMS=$(virsh list |grep -E 'worker|master'|awk '{print $2}')
KBS_VMS=$(virsh list --all|grep -E 'worker|master'|awk '{print $2}')
DCK_RUNNING_VMS=$(virsh list |grep 'node'|awk '{print $2}')
DCK_VMS=$(virsh list --all|grep 'node'|awk '{print $2}')

check_course () {
if ! [ -z "$(eval echo \$${CODE_FROM}_RUNNING_VMS)" ]
  then
     echo -e "$(eval echo \$${CODE_FROM}_RUNNING_VMS) still running"'!'"\n"
     echo "Shutting down."
       for vm in $(eval echo \$${CODE_FROM}_RUNNING_VMS)
          do
            virsh shutdown ${vm}
            virsh autostart ${vm} --disable
        done
     echo -e "\nWaiting 1 minute for shutdown\nPlease be patient."
     sleep 60
     for vm in $(eval echo \$${CODE_FROM}_RUNNING_VMS)
        do
          while virsh list |grep -q ${vm}
           do
             echo "${vm} shutdown forcible."
             virsh destroy ${vm}
           done
       done
fi
echo "Starting $(eval echo \$${CODE_TO}_VMS)"
for vm in $(eval echo \$${CODE_TO}_VMS)
    do
       virsh start ${vm}
       virsh autostart ${vm}
    done
}

echo -e "\nTo which course do you want to change? \n"
PS3="Select a number "

select COURSE in Docker Kubernetes
  do
    case ${COURSE} in
       Docker)
          CODE_TO=DCK
          CODE_FROM=KBS
          check_course
          exit
       ;;
       Kubernetes)
          CODE_TO=KBS
          CODE_FROM=DCK
          check_course
          exit
       ;;
   esac
done
