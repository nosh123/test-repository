#!/bin/bash

cp /etc/kubernetes/pki/ca.key ca-key.pem
cp /etc/kubernetes/pki/ca.crt ca.pem



curl https://pkg.cfssl.org/R1.2/cfssl_linux-amd64 -o /usr/local/bin/cfssl
curl https://pkg.cfssl.org/R1.2/cfssljson_linux-amd64 -o /usr/local/bin/cfssljson
chmod +x /usr/local/bin/cfssl /usr/local/bin/cfssljson


cfssl gencert -ca=ca.pem -ca-key=ca-key.pem --config=ca-config.json -profile=kubernetes kubelet-csr.json | cfssljson -bare kubelet

echo "copy to your nodes eg. master1 worker{1..3}"
echo "scp kubelet.pem <node-ip>:/var/lib/kubelet/pki/kubelet.crt"
for i in master1 worker{1..3}; do scp kubelet.pem $i:/var/lib/kubelet/pki/kubelet.crt ; done
echo "scp kubelet-key.pem <node-ip>:/var/lib/kubelet/pki/kubelet.key"
for i in master1 worker{1..3}; do scp kubelet-key.pem $i:/var/lib/kubelet/pki/kubelet.key ; done
echo "ssh <node-ip> systemctl restart kubelet"
for i in master1 worker{1..3}; do ssh $i systemctl restart kubelet ; done

echo "Done!"
